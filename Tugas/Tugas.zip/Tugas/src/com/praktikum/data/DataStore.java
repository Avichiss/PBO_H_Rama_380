package com.praktikum.data;

import java.util.ArrayList;
import com.praktikum.users.User;

public class DataStore {
    public static ArrayList<User> userList = new ArrayList<>();
    public static ArrayList<Item> reportedItem = new ArrayList<>();
}
