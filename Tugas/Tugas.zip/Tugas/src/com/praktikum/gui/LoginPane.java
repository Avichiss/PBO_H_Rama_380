package com.praktikum.gui;

import com.praktikum.main.LoginSystem;
import com.praktikum.users.Admin;
import com.praktikum.users.Mahasiswa;
import com.praktikum.users.User;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginPane extends VBox {
    public LoginPane(Stage stage) {
        Label title = new Label("Login Sistem Lost & Found");

        ComboBox<String> loginType = new ComboBox<>();
        loginType.getItems().addAll("Mahasiswa", "Admin");
        loginType.setPromptText("Pilih Login");
        loginType.setPrefWidth(300);

        TextField username = new TextField();
        username.setPromptText("Username");
        username.setPrefWidth(300);

        PasswordField password = new PasswordField();
        password.setPromptText("Password");
        password.setPrefWidth(300);

        Button login = new Button("Login");
        login.setPrefWidth(300);

        login.setOnAction(e -> {
            User tryLogin = LoginSystem.doLogin(username.getText(), password.getText());

            if (tryLogin == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("User tidak ditemukan");
                alert.show();
            } else {
                LoginSystem.currentUser = tryLogin;

                if (tryLogin instanceof Admin && "Admin".equals(loginType.getValue())) {
                    stage.setScene(new Scene(new AdminDashboard(stage), 1000, 600));
                } else if (tryLogin instanceof Mahasiswa && "Mahasiswa".equals(loginType.getValue())) {
                    stage.setScene(new Scene(new MahasiswaDashboard(stage), 1000, 600));
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Login Invalid");
                    alert.show();
                }
            }
        });

        this.setSpacing(20);
        this.setPadding(new Insets(50));
        this.setAlignment(Pos.CENTER);
        this.setMaxWidth(360);

        this.getChildren().addAll(title, loginType, username, password, login);
    }
}
